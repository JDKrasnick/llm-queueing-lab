"""Build the exact baseline and export one shared public model in the authorized L4 runtime."""
import concurrent.futures
import hashlib
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import sysconfig
import tarfile
import zipfile

stage = Path('/content/planner-validation')
source = Path('/content/planner-source')
source.mkdir(exist_ok=False)
with tarfile.open(stage / 'planner-source-baseline.tar.gz') as archive:
    archive.extractall(source, filter='data')
def run(args, **kwargs):
    print('COMMAND', args, flush=True)
    subprocess.run(args, check=True, **kwargs)

run([sys.executable, '-m', 'pip', 'install', 'cmake==3.31.10', 'ninja==1.13.2', 'numpy==2.1.3', 'requests==2.33.0', 'wheel==0.47.0', 'pybind11==3.0.4',
     'onnxruntime==1.31.0', 'onnx', 'onnx-ir', 'transformers>=5.0.0',
     'huggingface-hub', 'einops', 'nvidia-cuda-runtime-cu12', 'nvidia-cublas-cu12',
     'nvidia-cudnn-cu12', 'nvidia-cufft-cu12', 'nvidia-curand-cu12'])
run([sys.executable, '-m', 'pip', 'install', '--index-url',
     'https://aiinfra.pkgs.visualstudio.com/PublicPackages/_packaging/onnxruntime-cuda-12/pypi/simple/',
     'onnxruntime-ep-cuda12==0.3.0'])
site = Path(sysconfig.get_path('platlib'))
ort = Path('/content/planner-ort-home')
(ort / 'include').mkdir(parents=True)
(ort / 'lib').mkdir()
for p in (stage / 'headers').iterdir():
    shutil.copy2(p, ort / 'include' / p.name)
runtime = next((site / 'onnxruntime/capi').glob('libonnxruntime.so.*'))
for name in ['libonnxruntime.so', runtime.name]:
    (ort / 'lib' / name).symlink_to(runtime)
ld = ':'.join([str(ort/'lib'), *map(str, site.glob('nvidia/*/lib')), '/usr/local/cuda/lib64', '/usr/lib64-nvidia'])
env = dict(os.environ, LD_LIBRARY_PATH=ld, OMP_NUM_THREADS='4', CMAKE_BUILD_PARALLEL_LEVEL='4')
(stage / 'environment.json').write_text(json.dumps({'LD_LIBRARY_PATH': ld, 'OMP_NUM_THREADS': '4'}))
def build():
    run([sys.executable, 'build.py', '--update', '--config', 'Release', '--use_cuda',
         '--cuda_home', '/usr/local/cuda', '--ort_home', str(ort), '--skip_tests',
         '--skip_examples', '--cmake_generator', 'Ninja', '--cmake_extra_defines',
         'CMAKE_CUDA_ARCHITECTURES=89', 'ENABLE_TELEMETRY=OFF'], cwd=source, env=env)
    for target in ['engine_unit_tests', 'python', 'PyPackageBuild']:
        run(['cmake', '--build', str(source/'build/Linux/Release'), '--target', target, '--parallel', '4'], env=env)
    wheel = next((source/'build/Linux/Release/wheel').glob('*.whl'))
    shutil.copy2(wheel, stage / ('baseline-' + wheel.name))
    with zipfile.ZipFile(wheel) as archive:
        archive.extractall('/content/planner-baseline-package')
    (stage / 'baseline-wheel-sha256.txt').write_text(hashlib.sha256(wheel.read_bytes()).hexdigest())
def export():
    from huggingface_hub import snapshot_download
    revision = '7ae557604adf67be50417f59c2c2f167def9a775'
    checkpoint = snapshot_download('Qwen/Qwen2.5-0.5B-Instruct', revision=revision,
                                   allow_patterns=['*.json', '*.safetensors', '*.txt', '*.model'])
    run([sys.executable, 'src/python/py/models/builder.py', '-m', checkpoint,
         '-o', '/content/planner-qwen-paged', '-p', 'int4', '-e', 'cuda',
         '-c', '/content/planner-qwen-export-cache', '--extra_options',
         'use_paged_attention=true', 'shared_embeddings=false'], cwd=source, env=env)
with concurrent.futures.ThreadPoolExecutor(2) as pool:
    list(pool.map(lambda f: f(), [build, export]))
(stage / 'baseline-ready.json').write_text(json.dumps({
    'source': '3d0d6eb1327a959c54f2a41f6741ab9414e50286',
    'archive_sha256': hashlib.sha256((stage/'planner-source-baseline.tar.gz').read_bytes()).hexdigest(),
    'packages': {d.metadata['Name']: d.version for d in metadata.distributions()},
    'model': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/content/planner-qwen-paged').iterdir() if p.is_file()},
}, indent=2))
print('PLANNER_BASELINE_READY', flush=True)
